package gestiobancaria;

import java.time.LocalDate;

/**
 * Classe que representa una targeta de crèdit associada a un {@link CompteCorrent}.
 * <p>
 * Les targetes de crèdit emmagatzen el tipus (Visa, MasterCard, etc.),
 * el número de targeta, el titular i la data de caducitat.
 * Aquesta classe té una relació de <strong>composició</strong> amb CompteCorrent,
 * ja que una targeta no pot existir sense un compte corrent associat.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see CompteCorrent
 */
public class TargetaCredit {

    /** Tipus de targeta (p.ex. Visa, MasterCard, American Express). */
    private String tipus;

    /** Número de la targeta de crèdit. */
    private String numero;

    /** Nom del titular de la targeta. */
    private String titular;

    /** Data de caducitat de la targeta. */
    private LocalDate dataCaducitat;

    /**
     * Constructor per defecte de TargetaCredit.
     */
    public TargetaCredit() {
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param tipus         el tipus de targeta (Visa, MasterCard, etc.)
     * @param numero        el número de la targeta
     * @param titular       el nom del titular
     * @param dataCaducitat la data de caducitat
     */
    public TargetaCredit(String tipus, String numero, String titular, LocalDate dataCaducitat) {
        this.tipus = tipus;
        this.numero = numero;
        this.titular = titular;
        this.dataCaducitat = dataCaducitat;
    }

    /**
     * Obté el tipus de targeta.
     *
     * @return el tipus (Visa, MasterCard, etc.)
     */
    public String getTipus() {
        return tipus;
    }

    /**
     * Estableix el tipus de targeta.
     *
     * @param tipus el nou tipus
     */
    public void setTipus(String tipus) {
        this.tipus = tipus;
    }

    /**
     * Obté el número de la targeta.
     *
     * @return el número de targeta
     */
    public String getNumero() {
        return numero;
    }

    /**
     * Estableix el número de la targeta.
     *
     * @param numero el nou número
     */
    public void setNumero(String numero) {
        this.numero = numero;
    }

    /**
     * Obté el titular de la targeta.
     *
     * @return el nom del titular
     */
    public String getTitular() {
        return titular;
    }

    /**
     * Estableix el titular de la targeta.
     *
     * @param titular el nou titular
     */
    public void setTitular(String titular) {
        this.titular = titular;
    }

    /**
     * Obté la data de caducitat de la targeta.
     *
     * @return la data de caducitat
     */
    public LocalDate getDataCaducitat() {
        return dataCaducitat;
    }

    /**
     * Estableix la data de caducitat de la targeta.
     *
     * @param dataCaducitat la nova data de caducitat
     */
    public void setDataCaducitat(LocalDate dataCaducitat) {
        this.dataCaducitat = dataCaducitat;
    }

    /**
     * Comprova si la targeta ha caducat.
     *
     * @return {@code true} si la data de caducitat és anterior a la data actual
     */
    public boolean estaCaducada() {
        // Implementació futura
        return false;
    }

    /**
     * Retorna una representació en format String de la targeta de crèdit.
     *
     * @return una cadena amb les dades de la targeta
     */
    @Override
    public String toString() {
        return "TargetaCredit{" +
                "tipus='" + tipus + '\'' +
                ", numero='" + numero + '\'' +
                ", titular='" + titular + '\'' +
                ", dataCaducitat=" + dataCaducitat +
                '}';
    }
}
