package gestiobancaria;

/**
 * Classe abstracta que representa una persona dins del sistema bancari.
 * <p>
 * Aquesta classe serveix com a classe base per a {@link Client} i {@link Empleat},
 * encapsulant les dades comunes com el DNI, nom, adreça i telèfon.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 */
public abstract class Persona {

    /** Document Nacional d'Identitat de la persona. */
    private String dni;

    /** Nom complet de la persona. */
    private String nom;

    /** Adreça de residència de la persona. */
    private String adreca;

    /** Número de telèfon de contacte de la persona. */
    private String telefon;

    /**
     * Constructor per defecte de Persona.
     */
    public Persona() {
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param dni     el DNI de la persona
     * @param nom     el nom complet de la persona
     * @param adreca  l'adreça de la persona
     * @param telefon el telèfon de contacte
     */
    public Persona(String dni, String nom, String adreca, String telefon) {
        this.dni = dni;
        this.nom = nom;
        this.adreca = adreca;
        this.telefon = telefon;
    }

    /**
     * Obté el DNI de la persona.
     *
     * @return el DNI
     */
    public String getDni() {
        return dni;
    }

    /**
     * Estableix el DNI de la persona.
     *
     * @param dni el nou DNI
     */
    public void setDni(String dni) {
        this.dni = dni;
    }

    /**
     * Obté el nom de la persona.
     *
     * @return el nom complet
     */
    public String getNom() {
        return nom;
    }

    /**
     * Estableix el nom de la persona.
     *
     * @param nom el nou nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Obté l'adreça de la persona.
     *
     * @return l'adreça
     */
    public String getAdreca() {
        return adreca;
    }

    /**
     * Estableix l'adreça de la persona.
     *
     * @param adreca la nova adreça
     */
    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    /**
     * Obté el telèfon de la persona.
     *
     * @return el telèfon
     */
    public String getTelefon() {
        return telefon;
    }

    /**
     * Estableix el telèfon de la persona.
     *
     * @param telefon el nou telèfon
     */
    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    /**
     * Retorna una representació en format String de la persona.
     *
     * @return una cadena amb les dades de la persona
     */
    @Override
    public String toString() {
        return "Persona{" +
                "dni='" + dni + '\'' +
                ", nom='" + nom + '\'' +
                ", adreca='" + adreca + '\'' +
                ", telefon='" + telefon + '\'' +
                '}';
    }
}
