package gestiobancaria;

import java.time.LocalDate;

/**
 * Classe que representa un compte a termini del banc.
 * <p>
 * El compte a termini és un tipus de {@link Compte} que té una durada
 * determinada expressada en mesos. A diferència del {@link CompteCorrent},
 * el compte a termini <strong>no pot tenir</strong> targetes de crèdit
 * ni productes financers associats.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Compte
 * @see CompteCorrent
 */
public class CompteTermini extends Compte {

    /** Nombre de mesos que el compte estarà obert. */
    private int nombreMesos;

    /**
     * Constructor per defecte de CompteTermini.
     */
    public CompteTermini() {
        super();
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param numCompte    el número de compte
     * @param dataObertura la data d'obertura
     * @param saldo        el saldo inicial
     * @param tipusInteres el tipus d'interès
     * @param nombreMesos  el nombre de mesos de durada
     */
    public CompteTermini(String numCompte, LocalDate dataObertura, double saldo, 
                         double tipusInteres, int nombreMesos) {
        super(numCompte, dataObertura, saldo, tipusInteres);
        this.nombreMesos = nombreMesos;
    }

    /**
     * Obté el nombre de mesos del compte a termini.
     *
     * @return el nombre de mesos
     */
    public int getNombreMesos() {
        return nombreMesos;
    }

    /**
     * Estableix el nombre de mesos del compte a termini.
     *
     * @param nombreMesos el nou nombre de mesos
     */
    public void setNombreMesos(int nombreMesos) {
        this.nombreMesos = nombreMesos;
    }

    /**
     * Calcula la data de venciment del compte a termini.
     *
     * @return la data de venciment (data d'obertura + nombre de mesos)
     */
    public LocalDate calcularDataVenciment() {
        // Implementació futura
        return null;
    }

    /**
     * Retorna una representació en format String del compte a termini.
     *
     * @return una cadena amb les dades del compte a termini
     */
    @Override
    public String toString() {
        return "CompteTermini{" +
                "numCompte='" + getNumCompte() + '\'' +
                ", saldo=" + getSaldo() +
                ", nombreMesos=" + nombreMesos +
                '}';
    }
}
