package gestiobancaria;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe principal que representa el Banc.
 * <p>
 * El banc gestiona {@link Sucursal}, {@link Client} i {@link Empleat}.
 * Relació de composició amb Sucursal (les sucursals no existeixen sense el banc)
 * i d'agregació amb Client i Empleat.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 */
public class Banc {

    /** Nom del banc. */
    private String nom;

    /** Llista de sucursals del banc (composició). */
    private List<Sucursal> sucursals;

    /** Llista de clients del banc (agregació). */
    private List<Client> clients;

    /** Llista d'empleats del banc (agregació). */
    private List<Empleat> empleats;

    /**
     * Constructor per defecte de Banc.
     */
    public Banc() {
        this.sucursals = new ArrayList<>();
        this.clients = new ArrayList<>();
        this.empleats = new ArrayList<>();
    }

    /**
     * Constructor amb el nom del banc.
     *
     * @param nom el nom del banc
     */
    public Banc(String nom) {
        this.nom = nom;
        this.sucursals = new ArrayList<>();
        this.clients = new ArrayList<>();
        this.empleats = new ArrayList<>();
    }

    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }

    public List<Sucursal> getSucursals() { return sucursals; }
    public void setSucursals(List<Sucursal> sucursals) { this.sucursals = sucursals; }

    public List<Client> getClients() { return clients; }
    public void setClients(List<Client> clients) { this.clients = clients; }

    public List<Empleat> getEmpleats() { return empleats; }
    public void setEmpleats(List<Empleat> empleats) { this.empleats = empleats; }

    /**
     * Afegeix una sucursal al banc.
     * @param sucursal la sucursal a afegir
     */
    public void afegirSucursal(Sucursal sucursal) { this.sucursals.add(sucursal); }

    /**
     * Afegeix un client al banc.
     * @param client el client a afegir
     */
    public void afegirClient(Client client) { this.clients.add(client); }

    /**
     * Afegeix un empleat al banc.
     * @param empleat l'empleat a afegir
     */
    public void afegirEmpleat(Empleat empleat) { this.empleats.add(empleat); }

    /**
     * Cerca un client pel seu DNI.
     * @param dni el DNI a cercar
     * @return el client trobat o null
     */
    public Client cercarClient(String dni) { return null; }

    /**
     * Cerca un empleat pel seu DNI.
     * @param dni el DNI a cercar
     * @return l'empleat trobat o null
     */
    public Empleat cercarEmpleat(String dni) { return null; }

    @Override
    public String toString() {
        return "Banc{nom='" + nom + "', sucursals=" + sucursals.size() +
                ", clients=" + clients.size() + ", empleats=" + empleats.size() + "}";
    }
}
