package gestiobancaria;

/**
 * Classe que representa un valor dins d'una {@link CarteraValors}.
 * <p>
 * Un valor emmagatzema la informació d'un actiu financer individual,
 * incloent el seu nom, el nombre de títols i el preu de cotització.
 * Aquesta classe té una relació de <strong>composició</strong> amb
 * CarteraValors, ja que un valor no existeix fora d'una cartera.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see CarteraValors
 */
public class Valor {

    /** Nom del valor (p.ex. nom de l'empresa). */
    private String nomValor;

    /** Nombre de títols que es posseeixen d'aquest valor. */
    private int nombreTitols;

    /** Preu de cotització actual del valor (en euros). */
    private double preuCotitzacio;

    /**
     * Constructor per defecte de Valor.
     */
    public Valor() {
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param nomValor       el nom del valor
     * @param nombreTitols   el nombre de títols
     * @param preuCotitzacio el preu de cotització
     */
    public Valor(String nomValor, int nombreTitols, double preuCotitzacio) {
        this.nomValor = nomValor;
        this.nombreTitols = nombreTitols;
        this.preuCotitzacio = preuCotitzacio;
    }

    /**
     * Obté el nom del valor.
     *
     * @return el nom del valor
     */
    public String getNomValor() {
        return nomValor;
    }

    /**
     * Estableix el nom del valor.
     *
     * @param nomValor el nou nom
     */
    public void setNomValor(String nomValor) {
        this.nomValor = nomValor;
    }

    /**
     * Obté el nombre de títols.
     *
     * @return el nombre de títols
     */
    public int getNombreTitols() {
        return nombreTitols;
    }

    /**
     * Estableix el nombre de títols.
     *
     * @param nombreTitols el nou nombre de títols
     */
    public void setNombreTitols(int nombreTitols) {
        this.nombreTitols = nombreTitols;
    }

    /**
     * Obté el preu de cotització del valor.
     *
     * @return el preu en euros
     */
    public double getPreuCotitzacio() {
        return preuCotitzacio;
    }

    /**
     * Estableix el preu de cotització del valor.
     *
     * @param preuCotitzacio el nou preu
     */
    public void setPreuCotitzacio(double preuCotitzacio) {
        this.preuCotitzacio = preuCotitzacio;
    }

    /**
     * Calcula el valor total de la posició (nombre de títols × preu de cotització).
     *
     * @return el valor total en euros
     */
    public double calcularValorTotal() {
        // Implementació futura
        return 0.0;
    }

    /**
     * Retorna una representació en format String del valor.
     *
     * @return una cadena amb les dades del valor
     */
    @Override
    public String toString() {
        return "Valor{" +
                "nomValor='" + nomValor + '\'' +
                ", nombreTitols=" + nombreTitols +
                ", preuCotitzacio=" + preuCotitzacio +
                '}';
    }
}
