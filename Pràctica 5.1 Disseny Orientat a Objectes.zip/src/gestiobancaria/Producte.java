package gestiobancaria;

/**
 * Classe abstracta que representa un producte financer del banc.
 * <p>
 * Els productes financers poden ser associats a un {@link CompteCorrent}.
 * Les subclasses d'aquesta classe inclouen {@link FonsInversio} i {@link CarteraValors}.
 * </p>
 * <p>
 * Nota: Només els comptes corrents poden tenir productes associats,
 * els comptes a termini no.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see FonsInversio
 * @see CarteraValors
 * @see CompteCorrent
 */
public abstract class Producte {

    /** Nom identificatiu del producte financer. */
    private String nom;

    /**
     * Constructor per defecte de Producte.
     */
    public Producte() {
    }

    /**
     * Constructor amb el nom del producte.
     *
     * @param nom el nom del producte
     */
    public Producte(String nom) {
        this.nom = nom;
    }

    /**
     * Obté el nom del producte.
     *
     * @return el nom del producte
     */
    public String getNom() {
        return nom;
    }

    /**
     * Estableix el nom del producte.
     *
     * @param nom el nou nom del producte
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Mostra la informació detallada del producte.
     * Cada subclasse implementarà aquest mètode amb els seus detalls específics.
     *
     * @return una cadena amb la informació del producte
     */
    public abstract String mostrarInformacio();

    /**
     * Retorna una representació en format String del producte.
     *
     * @return una cadena amb les dades del producte
     */
    @Override
    public String toString() {
        return "Producte{" +
                "nom='" + nom + '\'' +
                '}';
    }
}
