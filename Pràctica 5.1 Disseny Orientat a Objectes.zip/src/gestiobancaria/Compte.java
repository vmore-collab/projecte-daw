package gestiobancaria;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe abstracta que representa un compte bancari genèric.
 * <p>
 * Aquesta classe conté els atributs comuns a tots els tipus de comptes bancaris
 * (número de compte, data d'obertura, saldo i tipus d'interès). Les subclasses
 * {@link CompteCorrent} i {@link CompteTermini} hereten d'aquesta classe i
 * afegeixen els seus atributs específics.
 * </p>
 * <p>
 * Un compte pot pertànyer a un o més {@link Client} (cotitulars).
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see CompteCorrent
 * @see CompteTermini
 * @see Client
 */
public abstract class Compte {

    /** Número identificatiu únic del compte. */
    private String numCompte;

    /** Data en què es va obrir el compte. */
    private LocalDate dataObertura;

    /** Saldo actual del compte en euros. */
    private double saldo;

    /** Tipus d'interès aplicat al compte (en percentatge). */
    private double tipusInteres;

    /** Llista de clients titulars del compte. */
    private List<Client> clients;

    /**
     * Constructor per defecte de Compte.
     */
    public Compte() {
        this.clients = new ArrayList<>();
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param numCompte    el número de compte
     * @param dataObertura la data d'obertura
     * @param saldo        el saldo inicial
     * @param tipusInteres el tipus d'interès
     */
    public Compte(String numCompte, LocalDate dataObertura, double saldo, double tipusInteres) {
        this.numCompte = numCompte;
        this.dataObertura = dataObertura;
        this.saldo = saldo;
        this.tipusInteres = tipusInteres;
        this.clients = new ArrayList<>();
    }

    /**
     * Obté el número de compte.
     *
     * @return el número de compte
     */
    public String getNumCompte() {
        return numCompte;
    }

    /**
     * Estableix el número de compte.
     *
     * @param numCompte el nou número de compte
     */
    public void setNumCompte(String numCompte) {
        this.numCompte = numCompte;
    }

    /**
     * Obté la data d'obertura del compte.
     *
     * @return la data d'obertura
     */
    public LocalDate getDataObertura() {
        return dataObertura;
    }

    /**
     * Estableix la data d'obertura del compte.
     *
     * @param dataObertura la nova data d'obertura
     */
    public void setDataObertura(LocalDate dataObertura) {
        this.dataObertura = dataObertura;
    }

    /**
     * Obté el saldo actual del compte.
     *
     * @return el saldo en euros
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * Estableix el saldo del compte.
     *
     * @param saldo el nou saldo
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    /**
     * Obté el tipus d'interès del compte.
     *
     * @return el tipus d'interès en percentatge
     */
    public double getTipusInteres() {
        return tipusInteres;
    }

    /**
     * Estableix el tipus d'interès del compte.
     *
     * @param tipusInteres el nou tipus d'interès
     */
    public void setTipusInteres(double tipusInteres) {
        this.tipusInteres = tipusInteres;
    }

    /**
     * Obté la llista de clients titulars del compte.
     *
     * @return la llista de clients
     */
    public List<Client> getClients() {
        return clients;
    }

    /**
     * Estableix la llista de clients titulars.
     *
     * @param clients la nova llista de clients
     */
    public void setClients(List<Client> clients) {
        this.clients = clients;
    }

    /**
     * Afegeix un client com a titular del compte.
     *
     * @param client el client a afegir
     */
    public void afegirClient(Client client) {
        this.clients.add(client);
    }

    /**
     * Realitza un ingrés al compte.
     *
     * @param quantitat la quantitat a ingressar (ha de ser positiva)
     */
    public void ingressar(double quantitat) {
        // Implementació futura
    }

    /**
     * Realitza una retirada del compte.
     *
     * @param quantitat la quantitat a retirar (ha de ser positiva i menor o igual al saldo)
     * @return {@code true} si la retirada s'ha realitzat correctament
     */
    public boolean retirar(double quantitat) {
        // Implementació futura
        return false;
    }

    /**
     * Consulta el saldo disponible al compte.
     *
     * @return el saldo disponible en euros
     */
    public double consultarSaldo() {
        return this.saldo;
    }

    /**
     * Retorna una representació en format String del compte.
     *
     * @return una cadena amb les dades del compte
     */
    @Override
    public String toString() {
        return "Compte{" +
                "numCompte='" + numCompte + '\'' +
                ", dataObertura=" + dataObertura +
                ", saldo=" + saldo +
                ", tipusInteres=" + tipusInteres +
                '}';
    }
}
