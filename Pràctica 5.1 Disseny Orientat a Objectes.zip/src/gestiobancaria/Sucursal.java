package gestiobancaria;

/**
 * Classe que representa una sucursal (oficina) del banc.
 * <p>
 * Cada sucursal té un identificador únic i una adreça. Els {@link Empleat}
 * del banc estan assignats a una sucursal concreta.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Empleat
 * @see Banc
 */
public class Sucursal {

    /** Identificador únic de la sucursal. */
    private String identificador;

    /** Adreça física de la sucursal. */
    private String adreca;

    /**
     * Constructor per defecte de Sucursal.
     */
    public Sucursal() {
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param identificador l'identificador únic de la sucursal
     * @param adreca        l'adreça de la sucursal
     */
    public Sucursal(String identificador, String adreca) {
        this.identificador = identificador;
        this.adreca = adreca;
    }

    /**
     * Obté l'identificador de la sucursal.
     *
     * @return l'identificador
     */
    public String getIdentificador() {
        return identificador;
    }

    /**
     * Estableix l'identificador de la sucursal.
     *
     * @param identificador el nou identificador
     */
    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }

    /**
     * Obté l'adreça de la sucursal.
     *
     * @return l'adreça
     */
    public String getAdreca() {
        return adreca;
    }

    /**
     * Estableix l'adreça de la sucursal.
     *
     * @param adreca la nova adreça
     */
    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    /**
     * Retorna una representació en format String de la sucursal.
     *
     * @return una cadena amb les dades de la sucursal
     */
    @Override
    public String toString() {
        return "Sucursal{" +
                "identificador='" + identificador + '\'' +
                ", adreca='" + adreca + '\'' +
                '}';
    }
}
