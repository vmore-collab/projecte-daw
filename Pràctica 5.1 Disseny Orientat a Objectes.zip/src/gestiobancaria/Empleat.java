package gestiobancaria;

/**
 * Classe que representa un empleat del banc.
 * <p>
 * Un empleat és una {@link Persona} que treballa en una {@link Sucursal} concreta
 * del banc. A diferència del {@link Client}, l'empleat no té comptes associats
 * directament, sinó una sucursal on treballa.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Persona
 * @see Sucursal
 */
public class Empleat extends Persona {

    /** Sucursal on treballa l'empleat. Relació d'associació. */
    private Sucursal sucursal;

    /**
     * Constructor per defecte d'Empleat.
     */
    public Empleat() {
        super();
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param dni      el DNI de l'empleat
     * @param nom      el nom complet de l'empleat
     * @param adreca   l'adreça de l'empleat
     * @param telefon  el telèfon de contacte de l'empleat
     * @param sucursal la sucursal on treballa l'empleat
     */
    public Empleat(String dni, String nom, String adreca, String telefon, Sucursal sucursal) {
        super(dni, nom, adreca, telefon);
        this.sucursal = sucursal;
    }

    /**
     * Obté la sucursal on treballa l'empleat.
     *
     * @return la sucursal assignada
     */
    public Sucursal getSucursal() {
        return sucursal;
    }

    /**
     * Estableix la sucursal on treballa l'empleat.
     *
     * @param sucursal la nova sucursal
     */
    public void setSucursal(Sucursal sucursal) {
        this.sucursal = sucursal;
    }

    /**
     * Retorna una representació en format String de l'empleat.
     *
     * @return una cadena amb les dades de l'empleat
     */
    @Override
    public String toString() {
        return "Empleat{" +
                "dni='" + getDni() + '\'' +
                ", nom='" + getNom() + '\'' +
                ", adreca='" + getAdreca() + '\'' +
                ", telefon='" + getTelefon() + '\'' +
                ", sucursal=" + (sucursal != null ? sucursal.getIdentificador() : "null") +
                '}';
    }
}
