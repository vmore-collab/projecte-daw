package gestiobancaria;

import java.time.LocalDate;

/**
 * Classe que representa un fons d'inversió del banc.
 * <p>
 * Un fons d'inversió és un {@link Producte} financer que pot ser associat
 * a un {@link CompteCorrent}. Conté informació sobre l'import invertit,
 * la rendibilitat esperada, i les dates d'obertura i venciment.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Producte
 * @see CompteCorrent
 */
public class FonsInversio extends Producte {

    /** Import invertit en el fons (en euros). */
    private double importInvertit;

    /** Rendibilitat esperada del fons (en percentatge). */
    private double rendibilitat;

    /** Data d'obertura del fons d'inversió. */
    private LocalDate dataObertura;

    /** Data de venciment del fons d'inversió. */
    private LocalDate dataVenciment;

    /**
     * Constructor per defecte de FonsInversio.
     */
    public FonsInversio() {
        super();
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param nom            el nom del fons
     * @param importInvertit l'import invertit
     * @param rendibilitat   la rendibilitat esperada
     * @param dataObertura   la data d'obertura
     * @param dataVenciment  la data de venciment
     */
    public FonsInversio(String nom, double importInvertit, double rendibilitat,
                        LocalDate dataObertura, LocalDate dataVenciment) {
        super(nom);
        this.importInvertit = importInvertit;
        this.rendibilitat = rendibilitat;
        this.dataObertura = dataObertura;
        this.dataVenciment = dataVenciment;
    }

    /**
     * Obté l'import invertit.
     *
     * @return l'import en euros
     */
    public double getImportInvertit() {
        return importInvertit;
    }

    /**
     * Estableix l'import invertit.
     *
     * @param importInvertit el nou import
     */
    public void setImportInvertit(double importInvertit) {
        this.importInvertit = importInvertit;
    }

    /**
     * Obté la rendibilitat del fons.
     *
     * @return la rendibilitat en percentatge
     */
    public double getRendibilitat() {
        return rendibilitat;
    }

    /**
     * Estableix la rendibilitat del fons.
     *
     * @param rendibilitat la nova rendibilitat
     */
    public void setRendibilitat(double rendibilitat) {
        this.rendibilitat = rendibilitat;
    }

    /**
     * Obté la data d'obertura del fons.
     *
     * @return la data d'obertura
     */
    public LocalDate getDataObertura() {
        return dataObertura;
    }

    /**
     * Estableix la data d'obertura del fons.
     *
     * @param dataObertura la nova data d'obertura
     */
    public void setDataObertura(LocalDate dataObertura) {
        this.dataObertura = dataObertura;
    }

    /**
     * Obté la data de venciment del fons.
     *
     * @return la data de venciment
     */
    public LocalDate getDataVenciment() {
        return dataVenciment;
    }

    /**
     * Estableix la data de venciment del fons.
     *
     * @param dataVenciment la nova data de venciment
     */
    public void setDataVenciment(LocalDate dataVenciment) {
        this.dataVenciment = dataVenciment;
    }

    /**
     * Calcula el benefici esperat del fons d'inversió.
     *
     * @return el benefici esperat en euros
     */
    public double calcularBenefici() {
        // Implementació futura
        return 0.0;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String mostrarInformacio() {
        return "FonsInversio{" +
                "nom='" + getNom() + '\'' +
                ", importInvertit=" + importInvertit +
                ", rendibilitat=" + rendibilitat + "%" +
                ", dataObertura=" + dataObertura +
                ", dataVenciment=" + dataVenciment +
                '}';
    }

    /**
     * Retorna una representació en format String del fons d'inversió.
     *
     * @return una cadena amb les dades del fons
     */
    @Override
    public String toString() {
        return mostrarInformacio();
    }
}
