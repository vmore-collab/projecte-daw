package gestiobancaria;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa una cartera de valors del banc.
 * <p>
 * Una cartera de valors és un {@link Producte} financer compost per diversos
 * {@link Valor}. Relació de composició amb Valor.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Producte
 * @see Valor
 */
public class CarteraValors extends Producte {

    private List<Valor> valors;

    public CarteraValors() {
        super();
        this.valors = new ArrayList<>();
    }

    public CarteraValors(String nom) {
        super(nom);
        this.valors = new ArrayList<>();
    }

    public List<Valor> getValors() { return valors; }
    public void setValors(List<Valor> valors) { this.valors = valors; }

    public void afegirValor(Valor valor) { this.valors.add(valor); }
    public boolean eliminarValor(Valor valor) { return this.valors.remove(valor); }

    public double calcularValorTotal() { return 0.0; }

    @Override
    public String mostrarInformacio() {
        return "CarteraValors{nom='" + getNom() + "', numValors=" + valors.size() + "}";
    }

    @Override
    public String toString() { return mostrarInformacio(); }
}
