package gestiobancaria;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa un compte corrent del banc.
 * <p>
 * El compte corrent és un tipus de {@link Compte} que permet tenir
 * {@link TargetaCredit} associades i {@link Producte} financers
 * (com {@link FonsInversio} i {@link CarteraValors}).
 * </p>
 * <p>
 * A diferència del {@link CompteTermini}, el compte corrent és l'únic
 * tipus de compte que pot tenir productes financers associats.
 * La relació amb TargetaCredit és de <strong>composició</strong> (les targetes
 * no existeixen sense el compte), mentre que la relació amb Producte
 * és d'<strong>agregació</strong> (els productes poden existir independentment).
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Compte
 * @see TargetaCredit
 * @see Producte
 */
public class CompteCorrent extends Compte {

    /** Llista de targetes de crèdit associades al compte (composició). */
    private List<TargetaCredit> targetesCredit;

    /** Llista de productes financers associats al compte (agregació). */
    private List<Producte> productes;

    /**
     * Constructor per defecte de CompteCorrent.
     */
    public CompteCorrent() {
        super();
        this.targetesCredit = new ArrayList<>();
        this.productes = new ArrayList<>();
    }

    /**
     * Constructor amb tots els paràmetres del compte.
     *
     * @param numCompte    el número de compte
     * @param dataObertura la data d'obertura
     * @param saldo        el saldo inicial
     * @param tipusInteres el tipus d'interès
     */
    public CompteCorrent(String numCompte, LocalDate dataObertura, double saldo, double tipusInteres) {
        super(numCompte, dataObertura, saldo, tipusInteres);
        this.targetesCredit = new ArrayList<>();
        this.productes = new ArrayList<>();
    }

    /**
     * Obté la llista de targetes de crèdit del compte.
     *
     * @return la llista de targetes de crèdit
     */
    public List<TargetaCredit> getTargetesCredit() {
        return targetesCredit;
    }

    /**
     * Estableix la llista de targetes de crèdit.
     *
     * @param targetesCredit la nova llista de targetes
     */
    public void setTargetesCredit(List<TargetaCredit> targetesCredit) {
        this.targetesCredit = targetesCredit;
    }

    /**
     * Afegeix una targeta de crèdit al compte.
     *
     * @param targeta la targeta a afegir
     */
    public void afegirTargeta(TargetaCredit targeta) {
        this.targetesCredit.add(targeta);
    }

    /**
     * Elimina una targeta de crèdit del compte.
     *
     * @param targeta la targeta a eliminar
     * @return {@code true} si la targeta s'ha eliminat correctament
     */
    public boolean eliminarTargeta(TargetaCredit targeta) {
        return this.targetesCredit.remove(targeta);
    }

    /**
     * Obté la llista de productes financers associats.
     *
     * @return la llista de productes
     */
    public List<Producte> getProductes() {
        return productes;
    }

    /**
     * Estableix la llista de productes financers.
     *
     * @param productes la nova llista de productes
     */
    public void setProductes(List<Producte> productes) {
        this.productes = productes;
    }

    /**
     * Afegeix un producte financer al compte corrent.
     *
     * @param producte el producte a afegir
     */
    public void afegirProducte(Producte producte) {
        this.productes.add(producte);
    }

    /**
     * Elimina un producte financer del compte corrent.
     *
     * @param producte el producte a eliminar
     * @return {@code true} si el producte s'ha eliminat correctament
     */
    public boolean eliminarProducte(Producte producte) {
        return this.productes.remove(producte);
    }

    /**
     * Retorna una representació en format String del compte corrent.
     *
     * @return una cadena amb les dades del compte corrent
     */
    @Override
    public String toString() {
        return "CompteCorrent{" +
                "numCompte='" + getNumCompte() + '\'' +
                ", saldo=" + getSaldo() +
                ", numTargetes=" + targetesCredit.size() +
                ", numProductes=" + productes.size() +
                '}';
    }
}
