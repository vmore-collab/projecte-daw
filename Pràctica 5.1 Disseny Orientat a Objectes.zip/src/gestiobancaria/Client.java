package gestiobancaria;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe que representa un client del banc.
 * <p>
 * Un client és una {@link Persona} que pot tenir un o més {@link Compte} bancaris
 * associats. El client pot ser titular de comptes corrents i comptes a termini.
 * </p>
 *
 * @author Victor
 * @version 1.0
 * @since 2026-05-08
 * @see Persona
 * @see Compte
 */
public class Client extends Persona {

    /** Llista de comptes bancaris associats al client. */
    private List<Compte> comptes;

    /**
     * Constructor per defecte de Client.
     * Inicialitza la llista de comptes buida.
     */
    public Client() {
        super();
        this.comptes = new ArrayList<>();
    }

    /**
     * Constructor amb tots els paràmetres.
     *
     * @param dni     el DNI del client
     * @param nom     el nom complet del client
     * @param adreca  l'adreça del client
     * @param telefon el telèfon de contacte del client
     */
    public Client(String dni, String nom, String adreca, String telefon) {
        super(dni, nom, adreca, telefon);
        this.comptes = new ArrayList<>();
    }

    /**
     * Obté la llista de comptes del client.
     *
     * @return llista de comptes bancaris
     */
    public List<Compte> getComptes() {
        return comptes;
    }

    /**
     * Estableix la llista de comptes del client.
     *
     * @param comptes la nova llista de comptes
     */
    public void setComptes(List<Compte> comptes) {
        this.comptes = comptes;
    }

    /**
     * Afegeix un compte bancari al client.
     *
     * @param compte el compte a afegir
     */
    public void afegirCompte(Compte compte) {
        this.comptes.add(compte);
    }

    /**
     * Elimina un compte bancari del client.
     *
     * @param compte el compte a eliminar
     * @return {@code true} si el compte s'ha eliminat correctament
     */
    public boolean eliminarCompte(Compte compte) {
        return this.comptes.remove(compte);
    }

    /**
     * Retorna una representació en format String del client.
     *
     * @return una cadena amb les dades del client
     */
    @Override
    public String toString() {
        return "Client{" +
                "dni='" + getDni() + '\'' +
                ", nom='" + getNom() + '\'' +
                ", adreca='" + getAdreca() + '\'' +
                ", telefon='" + getTelefon() + '\'' +
                ", numComptes=" + comptes.size() +
                '}';
    }
}
