# 🏦 Aplicació de Gestió Bancària - Disseny Orientat a Objectes (DOO)

Aquest repositori conté la pràctica final del Mòdul 5, centrada en el **Disseny Orientat a Objectes (DOO)** per a un sistema de gestió bancària. S'ha partit d'un enunciat textual per identificar les entitats del domini, establir les seves relacions i construir l'estructura de classes completa en Java.

## 📝 Descripció i Objectius del Projecte

L'objectiu principal del projecte és modelar una aplicació bancària capaç de gestionar sucursals, empleats, clients i un conjunt de productes financers (comptes corrents, comptes a termini, fons d'inversió i carteres de valors). 

El desenvolupament s'ha estructurat en les següents fases:
1. **Anàlisi Gramatical (Mètode Booch)**: Identificació de classes, atributs i mètodes a partir dels substantius i verbs de l'enunciat.
2. **Disseny UML**: Creació de diagrames de classes i diagrames de comportament.
3. **Implementació en Java**: Programació de l'esquelet de les classes, aplicant els conceptes d'herència, composició i agregació.
4. **Documentació JavaDoc**: Generació de l'API tècnica del projecte inserint etiquetes al codi font.

## 📂 Composició de l'Entrega (Estructura del Repositori)

El projecte s'organitza en els següents directoris clau:

- 📁 `src/` - Conté tot el **codi font Java** (l'esquelet de les 13 classes dissenyades). Inclou totes les etiquetes de comentaris necessàries per generar el JavaDoc de l'aplicació de gestió bancària.
- 📁 `diagrames/` - Conté els **diagrames UML** sol·licitats (classes, casos d'ús, seqüència, comunicació i activitat). S'han generat utilitzant codi PlantUML (`.puml`) i exportats a format `.png`.
- 📁 `documentacio/` - Conté l'**HTML generat pel JavaDoc** (fruit de les etiquetes JavaDoc posades al codi), que documenta completament les classes de l'aplicació. Pots obrir l'`index.html` d'aquesta carpeta per navegar per l'API.
- 📄 `documentacio_projecte.html / .pdf` - Document final de la pràctica amb les captures de pantalla i l'explicació i justificació detallada de tot el procés, relacions i patrons de disseny.

## 🏗️ Resum del Disseny de Classes i Relacions

El model inclou l'ús de classes abstractes (`Persona`, `Compte`, `Producte`) per agrupar comportaments i atributs comuns. 

**Relacions Principals Establertes:**
- **Composició**: `Banc` → `Sucursal` (les sucursals no existeixen sense el banc), `CompteCorrent` → `TargetaCredit`, `CarteraValors` → `Valor`.
- **Agregació**: `Banc` → `Client`, `Banc` → `Empleat`, `CompteCorrent` → `Producte`.
- **Associació**: `Client` ↔ `Compte` (1..*), `Empleat` → `Sucursal` (1..1).
- **Herència**: `Client` i `Empleat` hereten de `Persona`. `CompteCorrent` i `CompteTermini` hereten de `Compte`. `FonsInversio` i `CarteraValors` hereten de `Producte`.

## ⚙️ Tecnologies Utilitzades

- **Llenguatge:** Java 8+
- **Documentació de codi:** JavaDoc
- **Modelatge UML:** PlantUML (Visual Studio Code Extension)
- **Control de versions:** Git + GitHub

## 🚀 Com generar la documentació JavaDoc

Si es desitja tornar a generar el JavaDoc a partir del codi font, s'ha d'executar la següent comanda des de l'arrel del projecte:

```bash
javadoc -d documentacio -sourcepath src -subpackages gestiobancaria -charset UTF-8 -docencoding UTF-8
```

---
**Autor:** Victor | **Data:** Maig 2026
